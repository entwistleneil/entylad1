# -*- coding: utf-8 -*-
import urlparse,urllib2,urllib,re
import os
import sys
import plugintools
import xbmc
REMOTE_VERSION_FILE="http://"+plugintools.get_setting("server")+":88/ruya2/api/packages/version-kodi.txt"
LOCAL_VERSION_FILE=os.path.join(plugintools.get_runtime_path(),"version.txt")
def check_for_updates():
 pass
 try:
  pass
  data=plugintools.read(REMOTE_VERSION_FILE)
  remote_version=data.splitlines()[0]
  remote_file_url=data.splitlines()[1]
  pass
  infile=open(LOCAL_VERSION_FILE)
  data=infile.read()
  infile.close();
  local_version=data.splitlines()[0]
  pass
  if int(remote_version)>int(local_version):
   pass
   yes_pressed=plugintools.message_yes_no("RuYa IPTV","An update is available!","Do you want to install it now?")
   if yes_pressed:
    try:
     pass
     local_file_name=os.path.join(plugintools.get_data_path(),"update.zip")
     urllib.urlretrieve(remote_file_url,local_file_name)
     if not os.path.exists(local_file_name):
      pass
      raise Exception()
     pass
     import ziptools
     unzipper=ziptools.ziptools()
     destpathname=xbmc.translatePath("special://home/addons")
     pass
     unzipper.extract(local_file_name,destpathname)
     xbmc.executebuiltin((u'XBMC.Notification("Updated", "Please restart add-on to see the changes", 2000)'))
     xbmc.executebuiltin("Container.Refresh")
    except:
     xbmc.executebuiltin((u'XBMC.Notification("Not updated", "An error causes the update to fail", 2000)'))
    if os.path.exists(local_file_name):
     pass
     os.remove(local_file_name)
     pass
 except:
  import traceback
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
