# -*- coding: utf-8 -*-
import os
import sys
import urlparse,urllib,urllib2
import xbmc
import xbmcgui
import xbmcaddon
import plugintools
import api
from item import Item
window_stack=[]
def push_window(window):
 window_stack.append(window)
def pop_window():
 return window_stack.pop()
def go_to_home_window():
 pass
 for i in range(len(window_stack)-1):
  pass
  window=window_stack.pop()
  window.close()
def get_next_items(item):
 pass
 try:
  if item.action=="mainlist":
   pass
   itemlist=api.get_main_list()
  elif item.action=="livetv":
   pass
   itemlist=api.channels_list(plugintools.get_setting("last_channel_id"))
  elif item.action=="globalsearch":
   pass
   itemlist=api.main_search(item.url)
  else:
   pass
   itemlist=api.get_items(item)
 except:
  import traceback
  pass
  itemlist=[Item(title="Error",thumbnail=os.path.join(plugintools.get_runtime_path(),"resources","images","thumb_error.png"))]
 return itemlist
def get_window_for_item(item):
 pass
 if item.view=="menu":
  pass
  import window_menu
  window=window_menu.MenuWindow("menu.xml",plugintools.get_runtime_path())
 elif item.view=="catchup" or item.view=="episodes":
  pass
  import window_episodes
  window=window_episodes.EpisodesWindow("episodes.xml",plugintools.get_runtime_path())
 elif item.view=="movies" or item.view=="series" or item.view=="seasons":
  pass
  import window_posters
  window=window_posters.PostersWindow("posters.xml",plugintools.get_runtime_path())
 elif item.action=="livetv":
  pass
  import window_player_background
  window=window_player_background.PlayerWindowBackground("player_background.xml",plugintools.get_runtime_path())
 elif item.action=="stream_play":
  pass
  import window_detail
  if item.content_type=="serie" or item.content_type=="catchup":
   window=window_detail.DetailWindow("detail_serie.xml",plugintools.get_runtime_path())
  else:
   window=window_detail.DetailWindow("detail_movie.xml",plugintools.get_runtime_path())
 else:
  import window_menu
  window=window_menu.MenuWindow("menu.xml",plugintools.get_runtime_path())
 return window
# Created by pyminifier (https://github.com/liftoff/pyminifier)
