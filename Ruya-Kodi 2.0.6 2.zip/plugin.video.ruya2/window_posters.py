# -*- coding: utf-8 -*-
import os
import sys
import urlparse,urllib,urllib2
import xbmc
import xbmcgui
import xbmcaddon
import windowtools
from windowtools import*
import plugintools
import navigation
from item import Item
import api
class PostersWindow(xbmcgui.WindowXML):
 def __init__(self,xml_name,fallback_path):
  pass
  self.first_time=False
  self.parent_item=None
  self.itemlist=None
 def setParentItem(self,item):
  self.parent_item=item
 def setItemlist(self,itemlist):
  pass
  self.itemlist=[]
  for item in itemlist:
   pass
   self.itemlist.append(item)
 def onInit(self):
  pass
  if self.first_time==True:
   return
  self.first_time=True
  self.control_list=self.getControl(100)
  if self.itemlist is None:
   next_items=navigation.get_next_items(self.parent_item)
   self.setItemlist(next_items)
  for item in self.itemlist:
   pass
   list_item=xbmcgui.ListItem(item.title)
   if item.watched=="true":
    list_item.setArt({"thumb":"watched2.png"})
   list_item.setArt({"poster":item.thumbnail})
   self.control_list.addItem(list_item)
  result=api.check_message()
  if not result["error"]:
   plugintools.message("System notification",plugintools.htmlclean(result["body"]))
  self.setFocusId(100)
  self.getControl(400).setVisible(False)
 def onAction(self,action):
  pass
  if action==ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2:
   self.close()
  pos=self.control_list.getSelectedPosition()
  if pos>len(self.itemlist):
   return
  item=self.itemlist[pos]
  self.getControl(101).setText(item.plot)
  if action==ACTION_SELECT_ITEM or action==ACTION_MOUSE_LEFT_CLICK:
   if self.getFocusId()==100:
    pos=self.control_list.getSelectedPosition()
    item=self.itemlist[pos]
    next_window=navigation.get_window_for_item(item)
    next_window.setParentItem(item)
    navigation.push_window(next_window)
    next_window.doModal()
    del next_window
   elif self.getFocusId()==301:
    text_to_search=plugintools.keyboard_input("","Type what you want to search for")
    if text_to_search=="":
     return
    item=Item(action="globalsearch",url=text_to_search,view="menu")
    next_window=navigation.get_window_for_item(item)
    next_window.setParentItem(item)
    navigation.push_window(next_window)
    next_window.doModal()
    del next_window
   elif self.getFocusId()==302:
    plugintools.open_settings_dialog()
   elif self.getFocusId()==303:
    navigation.go_to_home_window()
 def onFocus(self,control_id):
  pass
  pos=self.control_list.getSelectedPosition()
  item=self.itemlist[pos]
  if item.plot!="":
   self.getControl(101).setText(item.plot)
 def onClick(self,control_id):
  pass
  pass
 def onControl(self,control):
  pass
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
