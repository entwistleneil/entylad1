# -*- coding: utf-8 -*-
import os
import sys
import urlparse,urllib,urllib2
import xbmc
import xbmcgui
import xbmcaddon
import windowtools
from windowtools import*
import plugintools
import navigation
from item import Item
import api
import custom_player
class DetailWindow(xbmcgui.WindowXML):
 def __init__(self,xml_name,fallback_path):
  pass
  self.first_time=False
  self.parent_item=None
  self.itemlist=None
  self.custom_player=None
 def setParentItem(self,item):
  self.parent_item=item
 def setItemlist(self,itemlist):
  pass
  self.itemlist=[]
  for item in itemlist:
   pass
   self.itemlist.append(item)
 def onInit(self):
  pass
  if self.custom_player is not None:
   pass
   if self.custom_player.isPlaying():
    pass
    self.custom_player.stop()
   else:
    pass
    self.custom_player.stop()
  else:
   pass
  if self.first_time==True:
   return
  self.first_time=True
  self.getControl(404).setImage(self.parent_item.thumbnail)
  self.getControl(405).setText("[COLOR ffffcf70]"+plugintools.htmlclean(self.parent_item.title)+"[/COLOR]\n\n"+plugintools.htmlclean(self.parent_item.plot))
  if self.parent_item.content_type=="catchup":
   self.getControl(406).setVisible(False)
   self.getControl(403).setVisible(False)
  else:
   if self.parent_item.watched=="true":
    self.getControl(406).setImage("watched2.png")
   if self.parent_item.is_favorite=="true":
    self.getControl(403).setLabel("Remove from favorites")
   else:
    self.getControl(403).setLabel("Add to favorites")
  result=api.check_message()
  if not result["error"]:
   plugintools.message("System notification",plugintools.htmlclean(result["body"]))
  self.setFocusId(401)
 def onAction(self,action):
  pass
  if action==ACTION_PARENT_DIR or action==ACTION_PREVIOUS_MENU or action==ACTION_PREVIOUS_MENU2:
   self.close()
  if action==ACTION_SELECT_ITEM or action==ACTION_MOUSE_LEFT_CLICK:
   if self.getFocusId()==401:
    play_item=self.parent_item.clone()
    play_item.url=api.append_session_to_url(play_item.url)+"&quality=low"
    self.custom_player=custom_player.CustomPlayer()
    self.custom_player.set_listener(self)
    self.custom_player.play_item(play_item)
   elif self.getFocusId()==402:
    play_item=self.parent_item.clone()
    play_item.url=api.append_session_to_url(play_item.url)+"&quality=high"
    self.custom_player=custom_player.CustomPlayer()
    self.custom_player.set_listener(self)
    self.custom_player.play_item(play_item)
   elif self.getFocusId()==502:
    play_item=self.parent_item.clone()
    play_item.url=api.append_session_to_url(play_item.url)+"&quality=fhd"
    self.custom_player=custom_player.CustomPlayer()
    self.custom_player.set_listener(self)
    self.custom_player.play_item(play_item)
   elif self.getFocusId()==403:
    content_id=self.parent_item.id
    if(self.parent_item.content_type=="serie"):
     content_id=self.parent_item.id_serie
    if self.parent_item.is_favorite=="true":
     api.favorites_remove("movie",content_id)
     plugintools.show_notification(self.parent_item.title,"Removed from favorites")
     self.parent_item.is_favorite="false"
     self.getControl(403).setLabel("Add to favorites")
    else:
     api.favorites_add("movie",content_id)
     plugintools.show_notification(self.parent_item.title,"Added to favorites")
     self.parent_item.is_favorite="true"
     self.getControl(403).setLabel("Remove from favorites")
   elif self.getFocusId()==301:
    text_to_search=plugintools.keyboard_input("","Type what you want to search for")
    if text_to_search=="":
     return
    item=Item(action="globalsearch",url=text_to_search,view="menu")
    next_window=navigation.get_window_for_item(item)
    next_window.setParentItem(item)
    navigation.push_window(next_window)
    next_window.doModal()
    del next_window
   elif self.getFocusId()==302:
    plugintools.open_settings_dialog()
   elif self.getFocusId()==303:
    navigation.go_to_home_window()
 def onFocus(self,control_id):
  pass
 def onClick(self,control_id):
  pass
  pass
 def onControl(self,control):
  pass
  pass
 def on_playback_stopped(self):
  pass
  self.custom_player=None
 def on_playback_ended(self):
  pass
  self.custom_player=None
# Created by pyminifier (https://github.com/liftoff/pyminifier)
