# -*- coding: utf-8 -*-
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
import urllib
import urllib2
import re
import sys
import os
import time
import socket
import json
from StringIO import StringIO
import gzip
application_log_enabled=False
module_log_enabled=False
http_debug_log_enabled=False
LIST="list"
THUMBNAIL="thumbnail"
MOVIES="movies"
TV_SHOWS="tvshows"
SEASONS="seasons"
EPISODES="episodes"
OTHER="other"
ALL_VIEW_CODES={'list':{'skin.confluence':50,'skin.aeon.nox':50,'skin.droid':50,'skin.quartz':50,'skin.re-touched':50,},'thumbnail':{'skin.confluence':500,'skin.aeon.nox':500,'skin.droid':51,'skin.quartz':51,'skin.re-touched':500,},'movies':{'skin.confluence':515,'skin.aeon.nox':500,'skin.droid':51,'skin.quartz':52,'skin.re-touched':500,},'tvshows':{'skin.confluence':515,'skin.aeon.nox':500,'skin.droid':51,'skin.quartz':52,'skin.re-touched':500,},'seasons':{'skin.confluence':50,'skin.aeon.nox':50,'skin.droid':50,'skin.quartz':52,'skin.re-touched':50,},'episodes':{'skin.confluence':504,'skin.aeon.nox':518,'skin.droid':50,'skin.quartz':52,'skin.re-touched':550,},}
def log(message):
 if application_log_enabled:
  xbmc.log(message,xbmc.LOGNOTICE)
def _log(message):
 if module_log_enabled:
  xbmc.log("plugintools."+message,xbmc.LOGNOTICE)
def get_params():
 pass
 param_string=sys.argv[2]
 pass
 commands={}
 if param_string:
  split_commands=param_string[param_string.find('?')+1:].split('&')
  for command in split_commands:
   pass
   if len(command)>0:
    if "=" in command:
     split_command=command.split('=')
     key=split_command[0]
     value=urllib.unquote_plus(split_command[1])
     commands[key]=value
    else:
     commands[command]=""
 pass
 return commands
def read(url):
 pass
 f=urllib2.urlopen(url)
 data=f.read()
 f.close()
 return data
def read_body_and_headers(url,post=None,headers=[],follow_redirects=False,timeout=30):
 pass
 if post is not None:
  pass
 if len(headers)==0:
  headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:18.0) Gecko/20100101 Firefox/18.0"])
 ficherocookies=os.path.join(get_data_path(),'cookies.dat')
 pass
 cj=None
 ClientCookie=None
 cookielib=None
 try:
  pass
  import cookielib
 except ImportError:
  pass
  try:
   pass
   import ClientCookie
  except ImportError:
   pass
   urlopen=urllib2.urlopen
   Request=urllib2.Request
  else:
   pass
   urlopen=ClientCookie.urlopen
   Request=ClientCookie.Request
   cj=ClientCookie.MozillaCookieJar()
 else:
  pass
  urlopen=urllib2.urlopen
  Request=urllib2.Request
  cj=cookielib.MozillaCookieJar()
 if cj is not None:
  pass
  if os.path.isfile(ficherocookies):
   pass
   try:
    cj.load(ficherocookies,ignore_discard=True)
   except:
    _log("read_body_and_headers Wrong cookie file, deleting...")
    os.remove(ficherocookies)
  if cookielib is not None:
   pass
   if not follow_redirects:
    opener=urllib2.build_opener(urllib2.HTTPHandler(debuglevel=http_debug_log_enabled),urllib2.HTTPCookieProcessor(cj),NoRedirectHandler())
   else:
    opener=urllib2.build_opener(urllib2.HTTPHandler(debuglevel=http_debug_log_enabled),urllib2.HTTPCookieProcessor(cj))
   urllib2.install_opener(opener)
  else:
   pass
   opener=ClientCookie.build_opener(ClientCookie.HTTPCookieProcessor(cj))
   ClientCookie.install_opener(opener)
 inicio=time.clock()
 txheaders={}
 if post is None:
  pass
 else:
  pass
 pass
 for header in headers:
  pass
  txheaders[header[0]]=header[1]
 pass
 req=Request(url,post,txheaders)
 handle=urlopen(req)
 '''
    if timeout is None:
        handle=urlopen(req)
    else:        
        #Disponible en python 2.6 en adelante --> handle = urlopen(req, timeout=timeout)
        #Para todas las versiones:
        try:
            import socket
            deftimeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(timeout)
            handle=urlopen(req)            
            socket.setdefaulttimeout(deftimeout)
        except:
            import sys
            for line in sys.exc_info():
                _log("%s" % line )
    ''' 
 cj.save(ficherocookies,ignore_discard=True)
 if handle.info().get('Content-Encoding')=='gzip':
  buf=StringIO(handle.read())
  f=gzip.GzipFile(fileobj=buf)
  data=f.read()
 else:
  data=handle.read()
 info=handle.info()
 pass
 returnheaders=[]
 pass
 for header in info:
  pass
  returnheaders.append([header,info[header]])
 handle.close()
 pass
 fin=time.clock()
 pass
 pass
 return data,returnheaders
class NoRedirectHandler(urllib2.HTTPRedirectHandler):
 def http_error_302(self,req,fp,code,msg,headers):
  infourl=urllib.addinfourl(fp,headers,req.get_full_url())
  infourl.status=code
  infourl.code=code
  return infourl
 http_error_300=http_error_302
 http_error_301=http_error_302
 http_error_303=http_error_302
 http_error_307=http_error_302
def find_multiple_matches(text,pattern):
 pass
 matches=re.findall(pattern,text,re.DOTALL)
 return matches
def find_single_match(text,pattern):
 pass
 result=""
 try: 
  matches=re.findall(pattern,text,flags=re.DOTALL)
  result=matches[0]
 except:
  result=""
 return result
def add_item(action="",title="",plot="",url="",thumbnail="",fanart="",show="",episode="",extra="",category="",page="",info_labels=None,context_menu_items=[],isPlayable=False,folder=True):
 pass
 listitem=xbmcgui.ListItem(title,iconImage="DefaultVideo.png",thumbnailImage=thumbnail)
 if info_labels is None:
  info_labels={"Title":title,"FileName":title,"Plot":plot}
 listitem.setInfo("video",info_labels)
 if len(context_menu_items)>0:
  listitem.addContextMenuItems(context_menu_items,replaceItems=False)
 if fanart!="":
  listitem.setProperty('fanart_image',fanart)
  xbmcplugin.setPluginFanart(int(sys.argv[1]),fanart)
 if url.startswith("plugin://"):
  itemurl=url
  listitem.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)
 elif isPlayable:
  listitem.setProperty("Video","true")
  listitem.setProperty('IsPlayable','true')
  itemurl='%s?action=%s&title=%s&url=%s&thumbnail=%s&fanart=%s&plot=%s&extra=%s&category=%s&page=%s'%(sys.argv[0],action,urllib.quote_plus(title),urllib.quote_plus(url),urllib.quote_plus(thumbnail),urllib.quote_plus(fanart),urllib.quote_plus(plot),urllib.quote_plus(extra),urllib.quote_plus(category),urllib.quote_plus(page))
  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)
 else:
  itemurl='%s?action=%s&title=%s&url=%s&thumbnail=%s&fanart=%s&plot=%s&extra=%s&category=%s&page=%s'%(sys.argv[0],action,urllib.quote_plus(title),urllib.quote_plus(url),urllib.quote_plus(thumbnail),urllib.quote_plus(fanart),urllib.quote_plus(plot),urllib.quote_plus(extra),urllib.quote_plus(category),urllib.quote_plus(page))
  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)
def close_item_list():
 pass
 xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True)
def play_resolved_url(url):
 pass
 listitem=xbmcgui.ListItem(path=url)
 listitem.setProperty('IsPlayable','true')
 return xbmcplugin.setResolvedUrl(int(sys.argv[1]),True,listitem)
def direct_play(url,title="",thumbnail="DefaultVideo.png",plot=""):
 pass
 try:
  xlistitem=xbmcgui.ListItem(title,iconImage=thumbnail,thumbnailImage=thumbnail,path=url)
 except:
  xlistitem=xbmcgui.ListItem(title,iconImage=thumbnail)
 xlistitem.setInfo("video",{"Title":title,"Plot":plot})
 playlist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
 playlist.clear()
 playlist.add(url,xlistitem)
 player_type=xbmc.PLAYER_CORE_AUTO
 xbmcPlayer=xbmc.Player(player_type)
 xbmcPlayer.play(playlist)
def show_picture(url):
 local_folder=os.path.join(get_data_path(),"images")
 if not os.path.exists(local_folder):
  try:
   os.mkdir(local_folder)
  except:
   pass
 local_file=os.path.join(local_folder,"temp.jpg")
 urllib.urlretrieve(url,local_file)
 xbmc.executebuiltin("SlideShow("+local_folder+")")
def get_temp_path():
 pass
 dev=xbmc.translatePath("special://temp/")
 pass
 return dev
def get_runtime_path():
 pass
 dev=xbmc.translatePath(__settings__.getAddonInfo('Path'))
 pass
 return dev
def get_data_path():
 pass
 dev=xbmc.translatePath(__settings__.getAddonInfo('Profile'))
 if not os.path.exists(dev):
  os.makedirs(dev)
 pass
 return dev
def get_setting(name):
 pass
 dev=__settings__.getSetting(name)
 pass
 return dev
def set_setting(name,value):
 pass
 __settings__.setSetting(name,value)
def open_settings_dialog():
 pass
 __settings__.openSettings()
def get_localized_string(code):
 pass
 dev=__language__(code)
 try:
  dev=dev.encode("utf-8")
 except:
  pass
 pass
 return dev
def keyboard_input(default_text="",title="",hidden=False):
 pass
 keyboard=xbmc.Keyboard(default_text,title,hidden)
 keyboard.doModal()
 if(keyboard.isConfirmed()):
  tecleado=keyboard.getText()
 else:
  tecleado=""
 pass
 return tecleado
def message(text1,text2="",text3=""):
 pass
 if text3=="":
  xbmcgui.Dialog().ok(text1,text2)
 elif text2=="":
  xbmcgui.Dialog().ok("",text1)
 else:
  xbmcgui.Dialog().ok(text1,text2,text3)
def message_yes_no(text1,text2="",text3=""):
 pass
 if text3=="":
  yes_pressed=xbmcgui.Dialog().yesno(text1,text2)
 elif text2=="":
  yes_pressed=xbmcgui.Dialog().yesno("",text1)
 else:
  yes_pressed=xbmcgui.Dialog().yesno(text1,text2,text3)
 return yes_pressed
def selector(option_list,title="Select one"):
 pass
 dia=xbmcgui.Dialog()
 selection=dia.select(title,option_list)
 return selection
def set_view(view_mode,view_code=0):
 pass
 if view_mode==MOVIES:
  pass
  xbmcplugin.setContent(int(sys.argv[1]),"movies")
 elif view_mode==TV_SHOWS:
  pass
  xbmcplugin.setContent(int(sys.argv[1]),"tvshows")
 elif view_mode==SEASONS:
  pass
  xbmcplugin.setContent(int(sys.argv[1]),"seasons")
 elif view_mode==EPISODES:
  pass
  xbmcplugin.setContent(int(sys.argv[1]),"episodes")
 skin_name=xbmc.getSkinDir()
 pass
 try:
  if view_code==0:
   pass
   view_codes=ALL_VIEW_CODES.get(view_mode)
   view_code=view_codes.get(skin_name)
   pass
   xbmc.executebuiltin("Container.SetViewMode("+str(view_code)+")")
  else:
   pass
   xbmc.executebuiltin("Container.SetViewMode("+str(view_code)+")")
 except:
  pass
def unescape(text):
 def fixup(m):
  text=m.group(0)
  if text[:2]=="&#":
   try:
    if text[:3]=="&#x": 
     return unichr(int(text[3:-1],16)).encode("utf-8")
    else:
     return unichr(int(text[2:-1])).encode("utf-8")
   except ValueError:
    logger.info("error de valor")
    pass
  else:
   try:
    import htmlentitydefs
    text=unichr(htmlentitydefs.name2codepoint[text[1:-1]]).encode("utf-8")
   except KeyError:
    logger.info("keyerror")
    pass
   except:
    pass
  return text 
 return re.sub("&#?\w+;",fixup,text)
def htmlclean(cadena):
 cadena=cadena.replace("<center>","")
 cadena=cadena.replace("</center>","")
 cadena=cadena.replace("<cite>","")
 cadena=cadena.replace("</cite>","")
 cadena=cadena.replace("<em>","")
 cadena=cadena.replace("</em>","")
 cadena=cadena.replace("<b>","")
 cadena=cadena.replace("</b>","")
 cadena=cadena.replace("<u>","")
 cadena=cadena.replace("</u>","")
 cadena=cadena.replace("<li>","")
 cadena=cadena.replace("</li>","")
 cadena=cadena.replace("<tbody>","")
 cadena=cadena.replace("</tbody>","")
 cadena=cadena.replace("<tr>","")
 cadena=cadena.replace("</tr>","")
 cadena=cadena.replace("<![CDATA[","")
 cadena=cadena.replace("<Br />","")
 cadena=cadena.replace("<BR />","")
 cadena=cadena.replace("<Br>","")
 cadena=re.compile("<script.*?</script>",re.DOTALL).sub("",cadena)
 cadena=re.compile("<option[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</option>","")
 cadena=re.compile("<i[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</iframe>","")
 cadena=cadena.replace("</i>","")
 cadena=re.compile("<table[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</table>","")
 cadena=re.compile("<td[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</td>","")
 cadena=re.compile("<div[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</div>","")
 cadena=re.compile("<dd[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</dd>","")
 cadena=re.compile("<font[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</font>","")
 cadena=re.compile("<strong[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</strong>","")
 cadena=re.compile("<small[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</small>","")
 cadena=re.compile("<span[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</span>","")
 cadena=re.compile("<a[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</a>","")
 cadena=re.compile("<p[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</p>","")
 cadena=re.compile("<ul[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</ul>","")
 cadena=re.compile("<h1[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</h1>","")
 cadena=re.compile("<h2[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</h2>","")
 cadena=re.compile("<h3[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</h3>","")
 cadena=re.compile("<h4[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</h4>","")
 cadena=re.compile("<!--[^-]+-->",re.DOTALL).sub("",cadena)
 cadena=re.compile("<img[^>]*>",re.DOTALL).sub("",cadena)
 cadena=re.compile("<br[^>]*>",re.DOTALL).sub("",cadena)
 cadena=re.compile("<object[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</object>","")
 cadena=re.compile("<param[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</param>","")
 cadena=re.compile("<embed[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</embed>","")
 cadena=re.compile("<title[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("</title>","")
 cadena=re.compile("<link[^>]*>",re.DOTALL).sub("",cadena)
 cadena=cadena.replace("\t","")
 cadena=unescape(cadena)
 return cadena
def slugify(title):
 title=title.replace("Á","a")
 title=title.replace("É","e")
 title=title.replace("Í","i")
 title=title.replace("Ó","o")
 title=title.replace("Ú","u")
 title=title.replace("á","a")
 title=title.replace("é","e")
 title=title.replace("í","i")
 title=title.replace("ó","o")
 title=title.replace("ú","u")
 title=title.replace("À","a")
 title=title.replace("È","e")
 title=title.replace("Ì","i")
 title=title.replace("Ò","o")
 title=title.replace("Ù","u")
 title=title.replace("à","a")
 title=title.replace("è","e")
 title=title.replace("ì","i")
 title=title.replace("ò","o")
 title=title.replace("ù","u")
 title=title.replace("ç","c")
 title=title.replace("Ç","C")
 title=title.replace("Ñ","n")
 title=title.replace("ñ","n")
 title=title.replace("/","-")
 title=title.replace("&amp;","&")
 title=title.lower().strip()
 validchars="abcdefghijklmnopqrstuvwxyz1234567890- "
 title=''.join(c for c in title if c in validchars)
 title=re.compile("\s+",re.DOTALL).sub(" ",title)
 title=re.compile("\s",re.DOTALL).sub("-",title.strip())
 title=re.compile("\-+",re.DOTALL).sub("-",title)
 if title.startswith("-"):
  title=title[1:]
 if title=="":
  title="-"+str(time.time())
 return title
def download(url,filename,resume_download=True):
 pass
 try:
  import xbmcgui
  if os.path.exists(filename)and resume_download:
   f=open(filename,'r+b')
   existSize=os.path.getsize(filename)
   pass
   downloaded=existSize
   f.seek(existSize)
  elif os.path.exists(filename)and not resume_download:
   pass
   return
  else:
   existSize=0
   pass
   f=open(filename,'wb')
   downloaded=0
  progress_dialog=xbmcgui.DialogProgress()
  progress_dialog.create("plugin","Descargando...",url,os.path.basename(filename))
  socket.setdefaulttimeout(60)
  if find_single_match(url,"http\://[a-z]+\:[a-z]+\@[a-z0-9\:\.]+/")!="":
   pass
   username=find_single_match(url,"http\://([a-z]+)\:[a-z]+\@[a-z0-9\:\.]+/")
   pass
   password=find_single_match(url,"http\://[a-z]+\:([a-z]+)\@[a-z0-9\:\.]+/")
   pass
   url="http://"+find_single_match(url,"http\://[a-z]+\:[a-z]+\@(.*?)$")
   pass
  else:
   username=""
  h=urllib2.HTTPHandler(debuglevel=0)
  request=urllib2.Request(url)
  if existSize>0:
   request.add_header('Range','bytes=%d-'%(existSize,))
  if username!="":
   user_and_pass=base64.b64encode(b""+username+":"+password+"").decode("ascii")
   pass
   request.add_header('Authorization','Basic '+user_and_pass)
  opener=urllib2.build_opener(h)
  urllib2.install_opener(opener)
  try:
   connexion=opener.open(request)
  except urllib2.HTTPError,e:
   pass
   f.close()
   progress_dialog.close()
   if e.code==416:
    return 0
   else:
    return-2
  try:
   total_size=int(connexion.headers["Content-Length"])
  except:
   total_size=1
  if existSize>0:
   total_size=total_size+existSize
  pass
  blocksize=100*1024
  readed_block=connexion.read(blocksize)
  pass
  maxretries=10
  while len(readed_block)>0:
   try:
    f.write(readed_block)
    downloaded=downloaded+len(readed_block)
    percent=int(float(downloaded)*100/float(total_size))
    totalmb=float(float(total_size)/(1024*1024))
    downloaded_mb=float(float(downloaded)/(1024*1024))
    retry_count=0
    while retry_count<=maxretries:
     try:
      before=time.time()
      readed_block=connexion.read(blocksize)
      after=time.time()
      if(after-before)>0:
       velocidad=len(readed_block)/((after-before))
       falta=total_size-downloaded
       if velocidad>0:
        tiempofalta=falta/velocidad
       else:
        tiempofalta=0
       progress_dialog.update(percent,"%.2fMB/%.2fMB (%d%%) %.2f Kb/s %s falta "%(downloaded_mb,totalmb,percent,velocidad/1024,sec_to_hms(tiempofalta)))
      break
      try:
       if xbmc.abortRequested:
        logger.error("XBMC Abort requested 1")
        return-1
      except:
       pass
     except:
      try:
       if xbmc.abortRequested:
        logger.error("XBMC Abort requested 2")
        return-1
      except:
       pass
      retry_count=retry_count+1
      _log("download ERROR in block download, retry %d"%retry_count)
      import traceback
      _log("download "+traceback.format_exc())
    try:
     if progress_dialog.iscanceled():
      _log("download Descarga del fichero cancelada")
      f.close()
      progress_dialog.close()
      return-1
    except:
     pass
    if retry_count>maxretries:
     _log("download ERROR en la descarga del fichero")
     f.close()
     progress_dialog.close()
     return-2
   except:
    import traceback
    _log("download "+traceback.format_exc())
    f.close()
    progress_dialog.close()
    return-2
 except:
  import traceback
  pass
 try:
  f.close()
 except:
  pass
 progress_dialog.close()
 pass
def sec_to_hms(seconds):
 m,s=divmod(int(seconds),60)
 h,m=divmod(m,60)
 return("%02d:%02d:%02d"%(h,m,s))
def get_safe_filename(original_filename):
 safe_filename=original_filename
 safe_filename=safe_filename.replace("Á","A")
 safe_filename=safe_filename.replace("É","E")
 safe_filename=safe_filename.replace("Í","I")
 safe_filename=safe_filename.replace("Ó","O")
 safe_filename=safe_filename.replace("Ú","U")
 safe_filename=safe_filename.replace("á","a")
 safe_filename=safe_filename.replace("é","e")
 safe_filename=safe_filename.replace("í","i")
 safe_filename=safe_filename.replace("ó","o")
 safe_filename=safe_filename.replace("ú","u")
 safe_filename=safe_filename.replace("À","A")
 safe_filename=safe_filename.replace("È","E")
 safe_filename=safe_filename.replace("Ì","I")
 safe_filename=safe_filename.replace("Ò","O")
 safe_filename=safe_filename.replace("Ù","U")
 safe_filename=safe_filename.replace("à","a")
 safe_filename=safe_filename.replace("è","e")
 safe_filename=safe_filename.replace("ì","i")
 safe_filename=safe_filename.replace("ò","o")
 safe_filename=safe_filename.replace("ù","u")
 safe_filename=safe_filename.replace("ç","c")
 safe_filename=safe_filename.replace("Ç","C")
 safe_filename=safe_filename.replace("Ñ","N")
 safe_filename=safe_filename.replace("ñ","n")
 safe_filename=safe_filename.replace("/","-")
 safe_filename=safe_filename.replace("&amp;","&")
 validchars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890- "
 safe_filename=''.join(c for c in safe_filename if c in validchars)
 safe_filename=re.compile("\s+",re.DOTALL).sub(" ",safe_filename)
 safe_filename=safe_filename.strip()
 if safe_filename=="":
  safe_filename="invalid"
 return safe_filename
def get_filename_from_url(url):
 import urlparse
 parsed_url=urlparse.urlparse(url)
 try:
  filename=parsed_url.path
 except:
  if len(parsed_url)>=4:
   filename=parsed_url[2]
  else:
   filename=""
 if len(filename)>0:
  if filename[-1:]=="/":
   filename=filename[:-1]
  if "/" in filename:
   filename=filename.split("/")[-1]
 return filename
def show_notification(title,message,icon=""):
 xbmc.executebuiltin((u'XBMC.Notification("'+title+'", "'+message+'", 2000, "'+icon+'")'))
def load_json(data):
 pass
 def to_utf8(dct):
  rdct={}
  for k,v in dct.items():
   if isinstance(v,(str,unicode)):
    rdct[k]=v.encode('utf8','ignore')
   else:
    rdct[k]=v
  return rdct
 json_data=json.loads(data,object_hook=to_utf8)
 pass
 return json_data
def dump_json(data):
 pass
 return json.dumps(data)
f=open(os.path.join(os.path.dirname(__file__),"addon.xml"))
data=f.read()
f.close()
addon_id=find_single_match(data,'id="([^"]+)"')
if addon_id=="":
 addon_id=find_single_match(data,"id='([^']+)'")
__settings__=xbmcaddon.Addon(id=addon_id)
__language__=__settings__.getLocalizedString
# Created by pyminifier (https://github.com/liftoff/pyminifier)
